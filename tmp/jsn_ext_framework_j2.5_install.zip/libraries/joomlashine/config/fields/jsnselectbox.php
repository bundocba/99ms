<?php
/**
 * @version    $Id$
 * @package    JSN_Framework
 * @author     JoomlaShine Team <support@joomlashine.com>
 * @copyright  Copyright (C) 2012 JoomlaShine.com. All Rights Reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Websites: http://www.joomlashine.com
 * Technical Support:  Feedback - http://www.joomlashine.com/contact-us/get-support.html
 */
defined('JPATH_BASE') or die;

/**
 * @deprecated  Form field renderer file is moved to jsnframework/libraries/joomlashine/form directory
 * @since       1.0.5
 */
require_once JSN_PATH_LIBRARIES . '/joomlashine/form/fields/' . basename(__FILE__);
